package com.my.bbs.controller.rest;

import com.my.bbs.common.Constants;
import com.my.bbs.common.ServiceResultEnum;
import com.my.bbs.entity.BBSPostComment;
import com.my.bbs.entity.BBSUser;
import com.my.bbs.service.BBSPostCommentService;
import com.my.bbs.util.Result;
import com.my.bbs.util.ResultGenerator;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
/*
* 这个控制器类处理与帖子评论相关的 HTTP 请求，提供了回复帖子和删除回复的功能。
* replyPost 方法：
功能：处理回复帖子的请求。
参数：
postId：帖子的 ID，通过 @RequestParam 注解从请求参数中获取。
parentCommentUserId：父评论用户的 ID，通过 @RequestParam 注解从请求参数中获取，可选参数。
commentBody：评论内容，通过 @RequestParam 注解从请求参数中获取。
verifyCode：验证码，通过 @RequestParam 注解从请求参数中获取。
httpSession：HttpSession 对象，用于获取当前用户的信息。
返回值：Result 对象，包含操作结果。
处理流程：
检查 postId 参数是否为空或小于 0，如果是则返回错误结果。
检查 commentBody 参数是否为空或长度超过 200 个字符，如果是则返回错误结果。
从 httpSession 中获取验证码，并与请求中的验证码进行比较，如果不匹配则返回错误结果。
从 httpSession 中获取当前用户的 BBSUser 对象。
创建一个 BBSPostComment 对象，并设置其属性。
调用 bbsPostCommentService 的 addPostComment 方法添加评论记录。
如果添加成功，返回成功结果，并从 httpSession 中移除验证码；如果添加失败，返回失败结果。
delReply 方法：
功能：处理删除回复的请求。
参数：
commentId：评论的 ID，通过 @PathVariable 注解从 URL 路径中获取。
httpSession：HttpSession 对象，用于获取当前用户的信息。
返回值：Result 对象，包含操作结果。
处理流程：
检查 commentId 参数是否为空或小于 0，如果是则返回错误结果。
从 httpSession 中获取当前用户的 BBSUser 对象。
调用 bbsPostCommentService 的 delPostComment 方法删除评论记录。
如果删除成功，返回成功结果；如果删除失败，返回失败结果
* */
@Controller
public class BBSPostCommentController {

    @Resource
    private BBSPostCommentService bbsPostCommentService;

    @PostMapping("/replyPost")
    @ResponseBody
    public Result replyPost(@RequestParam("postId") Long postId,
                            @RequestParam(value = "parentCommentUserId", required = false) Long parentCommentUserId,
                            @RequestParam("commentBody") String commentBody,
                            @RequestParam("verifyCode") String verifyCode,
                            HttpSession httpSession) {
        if (null == postId || postId < 0) {
            return ResultGenerator.genFailResult("postId参数错误");
        }
        if (!StringUtils.hasLength(commentBody)) {
            return ResultGenerator.genFailResult("commentBody参数错误");
        }
        if (commentBody.trim().length() > 200) {
            return ResultGenerator.genFailResult("评论内容过长");
        }
        String kaptchaCode = httpSession.getAttribute(Constants.VERIFY_CODE_KEY) + "";
//        if (!StringUtils.hasLength(kaptchaCode) || !verifyCode.equals(kaptchaCode)) {
//            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_VERIFY_CODE_ERROR.getResult());
//        }
        BBSUser bbsUser = (BBSUser) httpSession.getAttribute(Constants.USER_SESSION_KEY);

        BBSPostComment bbsPostComment = new BBSPostComment();
        bbsPostComment.setCommentBody(commentBody);
        bbsPostComment.setCommentUserId(bbsUser.getUserId());
        bbsPostComment.setParentCommentUserId(parentCommentUserId);
        bbsPostComment.setPostId(postId);

        if (bbsPostCommentService.addPostComment(bbsPostComment)) {
            httpSession.removeAttribute(Constants.VERIFY_CODE_KEY);
            return ResultGenerator.genSuccessResult();
        } else {
            return ResultGenerator.genFailResult("请求失败，请检查参数及账号是否有操作权限");
        }
    }


    @PostMapping("/delReply/{commentId}")
    @ResponseBody
    public Result delReply(@PathVariable("commentId") Long commentId,
                           HttpSession httpSession) {

        if (null == commentId || commentId < 0) {
            return ResultGenerator.genFailResult("commentId参数错误");
        }

        BBSUser bbsUser = (BBSUser) httpSession.getAttribute(Constants.USER_SESSION_KEY);

        if (bbsPostCommentService.delPostComment(commentId,bbsUser.getUserId())) {
            return ResultGenerator.genSuccessResult();
        } else {
            return ResultGenerator.genFailResult("请求失败，请检查参数及账号是否有操作权限");
        }
    }
}
