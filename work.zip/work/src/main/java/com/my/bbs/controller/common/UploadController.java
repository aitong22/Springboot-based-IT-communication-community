/**
 * 严肃声明：
 * 开源版本请务必保留此注释头信息，若删除我方将保留所有法律责任追究！
 * 可正常分享和学习源码，不得用于违法犯罪活动，违者必究！
 * Copyright (c) 2021 十三 all rights reserved.
 * 版权所有，侵权必究！
 */
package com.my.bbs.controller.common;

import com.my.bbs.common.Constants;
import com.my.bbs.util.Result;
import com.my.bbs.util.ResultGenerator;
import com.my.bbs.util.SystemUtil;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 处理文件上传的 HTTP 请求，并提供两个上传文件的方法：upload 和 uploadV2。
 * upload 方法：
 * 功能：处理单个文件的上传请求。
 * 参数：
 * httpServletRequest：HttpServletRequest 对象，用于获取请求信息。
 * file：MultipartFile 对象，代表上传的文件。
 * 返回值：Result 对象，包含上传结果。
 * 处理流程：
 * 获取上传文件的原始文件名。
 * 生成新的文件名，使用当前日期时间和随机数作为文件名的一部分，确保文件名的唯一性。
 * 创建目标文件的目录，如果目录不存在则创建。
 * 将上传的文件保存到目标目录。
 * 如果文件保存成功，返回成功结果，并将文件的访问路径设置为结果数据。
 * 如果文件保存失败，返回失败结果，并打印异常堆栈跟踪。
 * uploadV2 方法：
 * 功能：处理多个文件的上传请求。
 * 参数：
 * httpServletRequest：HttpServletRequest 对象，用于获取请求信息。
 * 返回值：Result 对象，包含上传结果。
 * 处理流程：
 * 创建一个列表来存储上传的文件。
 * 使用 CommonsMultipartResolver 解析请求，获取所有上传的文件。
 * 检查上传的文件数量是否超过限制（最多 5 个），如果超过则返回失败结果。
 * 遍历上传的文件列表，对每个文件进行处理：
 * 获取文件的原始文件名。
 * 生成新的文件名，使用当前日期时间和随机数作为文件名的一部分，确保文件名的唯一性。
 * 创建目标文件的目录，如果目录不存在则创建。
 * 将上传的文件保存到目标目录。
 * 将成功上传的文件的访问路径添加到结果列表中。
 * 如果所有文件都上传成功，返回成功结果，并将文件访问路径列表设置为结果数据。
 * 如果有文件上传失败，返回失败结果，并打印异常堆栈跟踪。
 */
@Controller
public class UploadController {

    @PostMapping({"/uploadFile"})
    @ResponseBody
    public Result upload(HttpServletRequest httpServletRequest, @RequestParam("file") MultipartFile file) throws URISyntaxException {
        String fileName = file.getOriginalFilename();
        String suffixName = fileName.substring(fileName.lastIndexOf("."));
        //生成文件名称通用方法
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
        Random r = new Random();
        StringBuilder tempName = new StringBuilder();
        tempName.append(sdf.format(new Date())).append(r.nextInt(100)).append(suffixName);
        String newFileName = tempName.toString();
        File fileDirectory = new File(Constants.FILE_UPLOAD_DIC);
        //创建文件
        File destFile = new File(Constants.FILE_UPLOAD_DIC + newFileName);
        try {
            if (!fileDirectory.exists()) {
                if (!fileDirectory.mkdir()) {
                    throw new IOException("文件夹创建失败,路径为：" + fileDirectory);
                }
            }
            file.transferTo(destFile);
            Result resultSuccess = ResultGenerator.genSuccessResult();
            resultSuccess.setData(SystemUtil.getHost(new URI(httpServletRequest.getRequestURL() + "")) + "/upload/" + newFileName);
            return resultSuccess;
        } catch (IOException e) {
            e.printStackTrace();
            return ResultGenerator.genFailResult("文件上传失败");
        }
    }

    @PostMapping({"/uploadFiles"})
    @ResponseBody
    public Result uploadV2(HttpServletRequest httpServletRequest) throws URISyntaxException {
        List<MultipartFile> multipartFiles = new ArrayList<>(8);
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(httpServletRequest.getSession().getServletContext());
        if (multipartResolver.isMultipart(httpServletRequest)) {
            MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) httpServletRequest;
            Iterator<String> iter = multiRequest.getFileNames();
            int total = 0;
            while (iter.hasNext()) {
                if (total > 5) {
                    return ResultGenerator.genFailResult("最多上传5张图片");
                }
                total += 1;
                MultipartFile file = multiRequest.getFile(iter.next());
                multipartFiles.add(file);
            }
        }
        if (CollectionUtils.isEmpty(multipartFiles)) {
            return ResultGenerator.genFailResult("参数异常");
        }
        if (multipartFiles != null && multipartFiles.size() > 5) {
            return ResultGenerator.genFailResult("最多上传5张图片");
        }
        List<String> fileNames = new ArrayList(multipartFiles.size());
        for (int i = 0; i < multipartFiles.size(); i++) {
            String fileName = multipartFiles.get(i).getOriginalFilename();
            String suffixName = fileName.substring(fileName.lastIndexOf("."));
            //生成文件名称通用方法
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
            Random r = new Random();
            StringBuilder tempName = new StringBuilder();
            tempName.append(sdf.format(new Date())).append(r.nextInt(100)).append(suffixName);
            String newFileName = tempName.toString();
            File fileDirectory = new File(Constants.FILE_UPLOAD_DIC);
            //创建文件
            File destFile = new File(Constants.FILE_UPLOAD_DIC + newFileName);
            try {
                if (!fileDirectory.exists()) {
                    if (!fileDirectory.mkdir()) {
                        throw new IOException("文件夹创建失败,路径为：" + fileDirectory);
                    }
                }
                multipartFiles.get(i).transferTo(destFile);
                fileNames.add(SystemUtil.getHost(new URI(httpServletRequest.getRequestURL() + "")) + "/upload/" + newFileName);
            } catch (IOException e) {
                e.printStackTrace();
                return ResultGenerator.genFailResult("文件上传失败");
            }
        }
        Result resultSuccess = ResultGenerator.genSuccessResult();
        resultSuccess.setData(fileNames);
        return resultSuccess;
    }

}
