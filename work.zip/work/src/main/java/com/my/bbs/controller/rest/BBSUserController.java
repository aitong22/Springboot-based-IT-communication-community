package com.my.bbs.controller.rest;

import com.my.bbs.common.Constants;
import com.my.bbs.common.ServiceResultEnum;
import com.my.bbs.entity.BBSPost;
import com.my.bbs.entity.BBSUser;
import com.my.bbs.entity.RecentCommentListEntity;
import com.my.bbs.service.BBSPostCollectService;
import com.my.bbs.service.BBSPostCommentService;
import com.my.bbs.service.BBSPostService;
import com.my.bbs.service.BBSUserService;
import com.my.bbs.util.MD5Util;
import com.my.bbs.util.PatternUtil;
import com.my.bbs.util.Result;
import com.my.bbs.util.ResultGenerator;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
/*
处理 HTTP GET 和 POST 请求，提供了用户登录、注册、用户中心、
用户设置、我的中心、更新用户信息、更新头像、更新密码和注销等功能。
@Controller 注解：
这个注解表明该类是一个 Spring MVC 控制器，用于处理 HTTP 请求。
@Resource 注解：
这个注解用于注入 Spring 容器中的 bean，这里注入了 BBSUserService、BBSPostService、BBSPostCollectService 和 BBSPostCommentService 服务类。
@GetMapping 注解：
这个注解用于将 HTTP GET 请求映射到特定的处理方法上。
@PostMapping 注解：
这个注解用于将 HTTP POST 请求映射到特定的处理方法上。
@PathVariable 注解：
这个注解用于获取 URL 路径中的参数，并将其绑定到方法参数上。
@RequestParam 注解：
这个注解用于获取请求参数，并将其绑定到方法参数上。
@ResponseBody 注解：
这个注解用于将方法的返回值直接写入 HTTP 响应体中，通常用于返回 JSON 数据。
loginPage 方法：
功能：处理用户登录页面的请求。
参数：无。
返回值：String 类型，表示视图名称。
处理流程：
返回 "user/login" 视图，展示用户登录页面。
registerPage 方法：
功能：处理用户注册页面的请求。
参数：无。
返回值：String 类型，表示视图名称。
处理流程：
返回 "user/reg" 视图，展示用户注册页面。
userCenterPage 方法：
功能：处理用户中心页面的请求。
参数：
request：HttpServletRequest 对象，用于获取请求信息。
userId：用户的 ID，通过 @PathVariable 注解从 URL 路径中获取。
返回值：String 类型，表示视图名称。
处理流程：
获取用户的基本信息，如果用户不存在则返回 404 错误页面。
获取用户近期发布的帖子列表。
获取用户近期回复的内容列表。
将用户信息、帖子列表和回复列表封装到 request 域中。
返回 "user/home" 视图，展示用户中心页面。
userSetPage 方法：
功能：处理用户设置页面的请求。
参数：
request：HttpServletRequest 对象，用于获取请求信息。
返回值：String 类型，表示视图名称。
处理流程：
从 session 中获取当前用户的信息。
将用户信息封装到 request 域中。
返回 "user/set" 视图，展示用户设置页面。
myCenterPage 方法：
功能：处理我的中心页面的请求。
参数：
request：HttpServletRequest 对象，用于获取请求信息。
返回值：String 类型，表示视图名称。
处理流程：
从 session 中获取当前用户的信息。
获取用户发布的帖子列表。
获取用户收藏的帖子列表。
将用户信息、帖子列表和收藏列表封装到 request 域中。
返回 "user/index" 视图，展示我的中心页面。
updateInfo 方法：
功能：处理更新用户信息的请求。
参数：
nickName：用户的昵称，通过 @RequestParam 注解从请求参数中获取。
userGender：用户的性别，通过 @RequestParam 注解从请求参数中获取。
location：用户的位置，通过 @RequestParam 注解从请求参数中获取。
introduce：用户的介绍，通过 @RequestParam 注解从请求参数中获取。
httpSession：HttpSession 对象，用于获取 session 信息。
返回值：Result 对象，包含操作结果。
处理流程：
检查请求参数是否有效，如果无效则返回相应的错误结果。
从 session 中获取当前用户的信息。
更新用户的昵称、性别、位置和介绍。
调用 bbsUserService 的 updateUserInfo 方法更新用户信息。
如果更新成功，返回成功结果；如果更新失败，返回失败结果。
updateHeadImg 方法：
功能：处理更新用户头像的请求。
参数：
userHeadImg：用户的头像 URL，通过 @RequestParam 注解从请求参数中获取。
httpSession：HttpSession 对象，用于获取 session 信息。
返回值：Result 对象，包含操作结果。
处理流程：
检查请求参数是否有效，如果无效则返回相应的错误结果。
从 session 中获取当前用户的信息。
更新用户的头像 URL。
调用 bbsUserService 的 updateUserHeadImg 方法更新用户头像。
如果更新成功，返回成功结果；如果更新失败，返回失败结果。
passwordUpdate 方法：
功能：处理更新用户密码的请求。
参数：
request：HttpServletRequest 对象，用于获取请求信息。
originalPassword：用户的原始密码，通过 @RequestParam 注解从请求参数中获取。
newPassword：用户的新密码，通过 @RequestParam 注解从请求参数中获取。
返回值：Result 对象，包含操作结果。
处理流程：
检查请求参数是否有效，如果无效则返回相应的错误结果。
从 session 中获取当前用户的信息。
调用 bbsUserService 的 updatePassword 方法更新用户密码。
如果更新成功，清空 session 中的数据，并返回成功结果；如果更新失败，返回失败结果。
logout 方法：
功能：处理用户注销的请求。
参数：
httpSession：HttpSession 对象，用于获取 session 信息。
返回值：String 类型，表示视图名称。
处理流程：
从 session 中移除用户信息。
返回 "user/login" 视图，展示用户登录页面。
register 方法：
功能：处理用户注册的请求。
参数：
loginName：用户的登录名，通过 @RequestParam 注解从请求参数中获取。
verifyCode：用户的验证码，通过 @RequestParam 注解从请求参数中获取。
nickName：用户的昵称，通过 @RequestParam 注解从请求参数中获取。
password：用户的密码，通过 @RequestParam 注解从请求参数中获取。
httpSession：HttpSession 对象，用于获取 session 信息。
返回值：Result 对象，包含操作结果。
处理流程：
检查请求参数是否有效，如果无效则返回相应的错误结果。
调用 bbsUserService 的 register 方法注册用户。
如果注册成功，返回成功结果；如果注册失败，返回失败结果。
* */
@Controller
public class BBSUserController {

    @Resource
    private BBSUserService bbsUserService;

    @Resource
    private BBSPostService bbsPostService;

    @Resource
    private BBSPostCollectService bbsPostCollectService;

    @Resource
    private BBSPostCommentService bbsPostCommentService;

    @GetMapping({"/login", "/login.html"})
    public String loginPage() {
        return "user/login";
    }

    @GetMapping({"/register", "/register.html"})
    public String registerPage() {
        return "user/reg";
    }

    @GetMapping("/userCenter/{userId}")
    public String userCenterPage(HttpServletRequest request, @PathVariable("userId") Long userId) {
        //基本用户信息
        BBSUser bbsUser = bbsUserService.getUserById(userId);
        if (bbsUser == null) {
            return "error/error_404";
        }

        //近期发布的帖子
        List<BBSPost> recentPostList = bbsPostService.getRecentPostListByUserId(userId);

        //近期回复的内容
        List<RecentCommentListEntity> recentCommentList = bbsPostCommentService.getRecentCommentListByUserId(userId);

        request.setAttribute("bbsUser", bbsUser);
        request.setAttribute("recentPostList", recentPostList);
        request.setAttribute("recentCommentList", recentCommentList);
        return "user/home";
    }

    @GetMapping("/userSet")
    public String userSetPage(HttpServletRequest request) {
        BBSUser currentUser = (BBSUser) request.getSession().getAttribute(Constants.USER_SESSION_KEY);
        request.setAttribute("bbsUser", currentUser);
        return "user/set";
    }

    @GetMapping("/myCenter")
    public String myCenterPage(HttpServletRequest request) {

        //基本用户信息
        BBSUser currentUser = (BBSUser) request.getSession().getAttribute(Constants.USER_SESSION_KEY);

        //我发的贴
        List<BBSPost> myBBSPostList = bbsPostService.getMyBBSPostList(currentUser.getUserId());
        int myBBSPostCount = 0;
        if (!CollectionUtils.isEmpty(myBBSPostList)) {
            myBBSPostCount = myBBSPostList.size();
        }

        //我收藏的贴
        List<BBSPost> collectRecords = bbsPostCollectService.getCollectRecordsByUserId(currentUser.getUserId());
        int myCollectBBSPostCount = 0;
        if (!CollectionUtils.isEmpty(collectRecords)) {
            myCollectBBSPostCount = collectRecords.size();
        }

        request.setAttribute("myBBSPostList", myBBSPostList);
        request.setAttribute("myBBSPostCount", myBBSPostCount);
        request.setAttribute("collectRecords", collectRecords);
        request.setAttribute("myCollectBBSPostCount", myCollectBBSPostCount);
        request.setAttribute("bbsUser", currentUser);
        return "user/index";
    }

    @PostMapping("/updateUserInfo")
    @ResponseBody
    public Result updateInfo(@RequestParam("nickName") String nickName,
                             @RequestParam("userGender") int userGender,
                             @RequestParam("location") String location,
                             @RequestParam("introduce") String introduce,
                             HttpSession httpSession) {

        if (!StringUtils.hasLength(nickName)) {
            return ResultGenerator.genFailResult("nickName参数错误");
        }
        if (userGender < 1 || userGender > 2) {
            return ResultGenerator.genFailResult("userGender参数错误");
        }
        if (!StringUtils.hasLength(location)) {
            return ResultGenerator.genFailResult("location参数错误");
        }
        if (!StringUtils.hasLength(introduce)) {
            return ResultGenerator.genFailResult("introduce参数错误");
        }
        BBSUser bbsUser = (BBSUser) httpSession.getAttribute(Constants.USER_SESSION_KEY);
        bbsUser.setNickName(nickName);
        if (userGender == 1) {
            bbsUser.setGender("男");
        }
        if (userGender == 2) {
            bbsUser.setGender("女");
        }
        bbsUser.setLocation(location);
        bbsUser.setIntroduce(introduce);
        if (bbsUserService.updateUserInfo(bbsUser, httpSession)) {
            Result result = ResultGenerator.genSuccessResult();
            return result;
        } else {
            Result result = ResultGenerator.genFailResult("修改失败");
            return result;
        }
    }

    @PostMapping("/updateHeadImg")
    @ResponseBody
    public Result updateHeadImg(@RequestParam("userHeadImg") String userHeadImg,
                                HttpSession httpSession) {

        if (!StringUtils.hasLength(userHeadImg)) {
            return ResultGenerator.genFailResult("userHeadImg参数错误");
        }
        BBSUser bbsUser = (BBSUser) httpSession.getAttribute(Constants.USER_SESSION_KEY);
        bbsUser.setHeadImgUrl(userHeadImg);
        if (bbsUserService.updateUserHeadImg(bbsUser, httpSession)) {
            Result result = ResultGenerator.genSuccessResult();
            return result;
        } else {
            Result result = ResultGenerator.genFailResult("修改失败");
            return result;
        }
    }

    @PostMapping("/updatePassword")
    @ResponseBody
    public Result passwordUpdate(HttpServletRequest request, @RequestParam("originalPassword") String originalPassword,
                                 @RequestParam("newPassword") String newPassword) {
        if (!StringUtils.hasLength(originalPassword) || !StringUtils.hasLength(newPassword)) {
            return ResultGenerator.genFailResult("参数不能为空");
        }
        BBSUser currentUser = (BBSUser) request.getSession().getAttribute(Constants.USER_SESSION_KEY);
        if (bbsUserService.updatePassword(currentUser.getUserId(), originalPassword, newPassword)) {
            //修改成功后清空session中的数据，前端控制跳转至登录页
            request.getSession().removeAttribute(Constants.USER_SESSION_KEY);
            return ResultGenerator.genSuccessResult();
        } else {
            return ResultGenerator.genFailResult("修改失败");
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession httpSession) {
        httpSession.removeAttribute(Constants.USER_SESSION_KEY);
        return "user/login";
    }

    @PostMapping("/register")
    @ResponseBody
    public Result register(@RequestParam("loginName") String loginName,
                           @RequestParam("verifyCode") String verifyCode,
                           @RequestParam("nickName") String nickName,
                           @RequestParam("password") String password,
                           HttpSession httpSession) {
        if (!StringUtils.hasLength(loginName)) {
            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_NAME_NULL.getResult());
        }
        if (!PatternUtil.isEmail(loginName)) {
            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_NAME_NOT_EMAIL.getResult());
        }
        if (!StringUtils.hasLength(password)) {
            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_PASSWORD_NULL.getResult());
        }
//        if (!StringUtils.hasLength(verifyCode)) {
//            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_VERIFY_CODE_NULL.getResult());
//        }
        String kaptchaCode = httpSession.getAttribute(Constants.VERIFY_CODE_KEY) + "";
//        if (!StringUtils.hasLength(kaptchaCode) || !verifyCode.equals(kaptchaCode)) {
//            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_VERIFY_CODE_ERROR.getResult());
//        }
        String registerResult = bbsUserService.register(loginName, password, nickName);
        //注册成功
        if (ServiceResultEnum.SUCCESS.getResult().equals(registerResult)) {
            httpSession.removeAttribute(Constants.VERIFY_CODE_KEY);//删除session中的验证码
            return ResultGenerator.genSuccessResult();
        }
        //注册失败
        return ResultGenerator.genFailResult(registerResult);
    }


    @PostMapping("/login")
    @ResponseBody
    public Result login(@RequestParam("loginName") String loginName,
                        @RequestParam("verifyCode") String verifyCode,
                        @RequestParam("password") String password,
                        HttpSession httpSession) {
        if (!StringUtils.hasLength(loginName)) {
            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_NAME_NULL.getResult());
        }
        if (!PatternUtil.isEmail(loginName)) {
            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_NAME_NOT_EMAIL.getResult());
        }
        if (!StringUtils.hasLength(password)) {
            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_PASSWORD_NULL.getResult());
        }
//        if (!StringUtils.hasLength(verifyCode)) {
//            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_VERIFY_CODE_NULL.getResult());
//        }
        String kaptchaCode = httpSession.getAttribute(Constants.VERIFY_CODE_KEY) + "";
//        if (!StringUtils.hasLength(kaptchaCode) || !verifyCode.equals(kaptchaCode)) {
//            return ResultGenerator.genFailResult(ServiceResultEnum.LOGIN_VERIFY_CODE_ERROR.getResult());
//        }
        String loginResult = bbsUserService.login(loginName, MD5Util.MD5Encode(password, "UTF-8"), httpSession);
        //登录成功
        if (ServiceResultEnum.SUCCESS.getResult().equals(loginResult)) {
            httpSession.removeAttribute(Constants.VERIFY_CODE_KEY);//删除session中的验证码
            return ResultGenerator.genSuccessResult();
        }
        //登录失败
        return ResultGenerator.genFailResult(loginResult);
    }
}
