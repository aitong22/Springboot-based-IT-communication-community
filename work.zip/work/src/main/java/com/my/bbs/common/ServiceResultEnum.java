
package com.my.bbs.common;


/**
 * 定义服务结果枚举类，包含操作结果的常量
 */
public enum ServiceResultEnum {
    // 操作失败
    ERROR("error"),
    // 操作成功
    SUCCESS("success"),
    // 未查询到记录
    DATA_NOT_EXIST("未查询到记录！"),
    // 用户名已存在
    SAME_LOGIN_NAME_EXIST("用户名已存在！"),
    // 请输入登录名
    LOGIN_NAME_NULL("请输入登录名！"),
    // 请输入正确的邮箱
    LOGIN_NAME_NOT_EMAIL("请输入正确的邮箱！"),
    // 请输入密码
    LOGIN_PASSWORD_NULL("请输入密码！"),
    // 请输入验证码
    LOGIN_VERIFY_CODE_NULL("请输入验证码！"),
    // 验证码错误
    LOGIN_VERIFY_CODE_ERROR("验证码错误！"),
    // 登录失败
    LOGIN_ERROR("登录失败！"),
    // 数据库错误
    DB_ERROR("database error");

    private String result;

    /**
     * 构造函数，初始化结果描述
     * @param result 结果描述字符串
     */
    ServiceResultEnum(String result) {
        this.result = result;
    }

    /**
     * 获取结果描述
     * @return 结果描述字符串
     */
    public String getResult() {
        return result;
    }

    /**
     * 设置结果描述
     * @param result 结果描述字符串
     */
    public void setResult(String result) {
        this.result = result;
    }
}

