package com.my.bbs.controller.rest;

import com.my.bbs.common.Constants;
import com.my.bbs.entity.BBSPost;
import com.my.bbs.entity.BBSUser;
import com.my.bbs.service.BBSPostCategoryService;
import com.my.bbs.service.BBSPostCollectService;
import com.my.bbs.service.BBSPostService;
import com.my.bbs.service.BBSUserService;
import com.my.bbs.util.Result;
import com.my.bbs.util.ResultGenerator;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
/*
这个控制器类处理与帖子收藏相关的 HTTP 请求，提供了添加收藏和删除收藏的功能。

addCollect 方法：
功能：处理添加收藏的请求。
参数：
postId：帖子的 ID，通过 @PathVariable 注解从 URL 路径中获取。
httpSession：HttpSession 对象，用于获取当前用户的信息。
返回值：Result 对象，包含操作结果。
处理流程：
检查 postId 参数是否为空或小于 0，如果是则返回错误结果。
从 httpSession 中获取当前用户的 BBSUser 对象。
调用 bbsPostCollectService 的 addCollectRecord 方法添加收藏记录。
如果添加成功，返回成功结果；如果添加失败，返回失败结果。
delCollect 方法：
功能：处理删除收藏的请求。
参数：
postId：帖子的 ID，通过 @PathVariable 注解从 URL 路径中获取。
httpSession：HttpSession 对象，用于获取当前用户的信息。
返回值：Result 对象，包含操作结果。
处理流程：
检查 postId 参数是否为空或小于 0，如果是则返回错误结果。
从 httpSession 中获取当前用户的 BBSUser 对象。
调用 bbsPostCollectService 的 deleteCollectRecord 方法删除收藏记录。
如果删除成功，返回成功结果；如果删除失败，返回失败结果。
* */
@Controller
public class BBSPostCollectController {

    @Resource
    private BBSPostCollectService bbsPostCollectService;

    @PostMapping("/addCollect/{postId}")
    @ResponseBody
    public Result addCollect(@PathVariable("postId") Long postId,
                             HttpSession httpSession) {
        if (null == postId || postId < 0) {
            return ResultGenerator.genFailResult("postId参数错误");
        }
        BBSUser bbsUser = (BBSUser) httpSession.getAttribute(Constants.USER_SESSION_KEY);
        if (bbsPostCollectService.addCollectRecord(bbsUser.getUserId(), postId)) {
            return ResultGenerator.genSuccessResult();
        } else {
            return ResultGenerator.genFailResult("请求失败，请检查参数及账号是否有操作权限");
        }
    }

    @PostMapping("/delCollect/{postId}")
    @ResponseBody
    public Result delCollect(@PathVariable("postId") Long postId,
                             HttpSession httpSession) {
        if (null == postId || postId < 0) {
            return ResultGenerator.genFailResult("postId参数错误");
        }
        BBSUser bbsUser = (BBSUser) httpSession.getAttribute(Constants.USER_SESSION_KEY);
        if (bbsPostCollectService.deleteCollectRecord(bbsUser.getUserId(), postId)) {
            return ResultGenerator.genSuccessResult();
        } else {
            return ResultGenerator.genFailResult("请求失败，请检查参数及账号是否有操作权限");
        }
    }
}
