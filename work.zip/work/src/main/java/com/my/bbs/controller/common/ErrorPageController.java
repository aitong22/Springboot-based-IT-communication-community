
package com.my.bbs.controller.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;
/**
 /**
 它实现了 ErrorController 接口，用于处理 Spring Boot
 应用程序中的错误页面它实现了 ErrorController 接口，
 用于处理 Spring Boot 应用程序中的错误页面
 据不同的错误类型返回相应的 HTML 页面或 JSON 响应。

 构造函数：
 ErrorPageController(ErrorAttributes errorAttributes)：这个构造函数用于初始化 ErrorAttributes 对象。
 ErrorPageController()：这个构造函数用于单例模式，如果 errorPageController 为 null，则创建一个新的实例。

 errorHtml 方法：
 功能：处理 /error 路径的 HTTP 请求，并根据错误状态码返回相应的 HTML 页面。
 参数：HttpServletRequest request，用于获取请求信息。
 返回值：ModelAndView 对象，包含视图名称和模型数据。
 处理流程：
 获取请求的状态码。
 根据状态码返回相应的视图名称，如 error/error_400 表示 400 错误，error/error_404 表示 404 错误，error/error_5xx 表示 500 及以上错误。
 error 方法：
 功能：处理 /error 路径的 HTTP 请求，并返回包含错误信息的 JSON 响应。
 参数：HttpServletRequest request，用于获取请求信息。
 返回值：ResponseEntity<Map<String, Object>> 对象，包含响应的状态码和错误信息。
 处理流程：
 获取请求的错误属性，包括错误信息和堆栈跟踪。
 根据请求的状态码返回相应的 JSON 响应。
 getErrorPath 方法：
 功能：返回错误处理的路径。
 返回值：String 类型，表示错误处理的路径。
 getTraceParameter 方法：
 功能：获取请求中的 trace 参数，用于决定是否包含堆栈跟踪信息。
 参数：HttpServletRequest request，用于获取请求信息。
 返回值：boolean 类型，表示是否包含堆栈跟踪信息。
 getErrorAttributes 方法：
 功能：获取请求的错误属性，包括错误信息和堆栈跟踪。
 参数：HttpServletRequest request，用于获取请求信息；boolean includeStackTrace，用于决定是否包含堆栈跟踪信息。
 返回值：Map<String, Object> 类型，表示错误属性。
 getStatus 方法：
 功能：获取请求的状态码。
 参数：HttpServletRequest request，用于获取请求信息。
 返回值：HttpStatus 类型，表示请求的状态码。
 */

@Controller
public class ErrorPageController implements ErrorController {

    private static ErrorPageController errorPageController;

    @Autowired
    private ErrorAttributes errorAttributes;

    private final static String ERROR_PATH = "/error";

    public ErrorPageController(ErrorAttributes errorAttributes) {
        this.errorAttributes = errorAttributes;
    }

    public ErrorPageController() {
        if (errorPageController == null) {
            errorPageController = new ErrorPageController(errorAttributes);
        }
    }

    @RequestMapping(value = ERROR_PATH, produces = "text/html")
    public ModelAndView errorHtml(HttpServletRequest request) {
        HttpStatus status = getStatus(request);
        if (HttpStatus.BAD_REQUEST == status) {
            return new ModelAndView("error/error_400");
        } else if (HttpStatus.NOT_FOUND == status) {
            return new ModelAndView("error/error_404");
        } else {
            return new ModelAndView("error/error_5xx");
        }
    }

    @RequestMapping(value = ERROR_PATH)
    @ResponseBody
    public ResponseEntity<Map<String, Object>> error(HttpServletRequest request) {
        Map<String, Object> body = getErrorAttributes(request, getTraceParameter(request));
        HttpStatus status = getStatus(request);
        return new ResponseEntity<Map<String, Object>>(body, status);
    }

    @Override
    public String getErrorPath() {
        return ERROR_PATH;
    }


    private boolean getTraceParameter(HttpServletRequest request) {
        String parameter = request.getParameter("trace");
        if (parameter == null) {
            return false;
        }
        return !"false".equals(parameter.toLowerCase());
    }

    protected Map<String, Object> getErrorAttributes(HttpServletRequest request, boolean includeStackTrace) {
        WebRequest webRequest = new ServletWebRequest(request);
        return this.errorAttributes.getErrorAttributes(webRequest, includeStackTrace);
    }

    private HttpStatus getStatus(HttpServletRequest request) {
        Integer statusCode = (Integer) request
                .getAttribute("javax.servlet.error.status_code");
        if (statusCode != null) {
            try {
                return HttpStatus.valueOf(statusCode);
            } catch (Exception ex) {
            }
        }
        return HttpStatus.INTERNAL_SERVER_ERROR;
    }
}
